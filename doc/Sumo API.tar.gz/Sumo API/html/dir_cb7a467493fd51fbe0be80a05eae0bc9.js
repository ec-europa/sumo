var dir_cb7a467493fd51fbe0be80a05eae0bc9 =
[
    [ "ShapefileDataStore.java", "_shapefile_data_store_8java.html", [
      [ "ShapefileDataStore", "classorg_1_1geotools_1_1data_1_1shapefile_1_1_shapefile_data_store.html", "classorg_1_1geotools_1_1data_1_1shapefile_1_1_shapefile_data_store" ]
    ] ]
];