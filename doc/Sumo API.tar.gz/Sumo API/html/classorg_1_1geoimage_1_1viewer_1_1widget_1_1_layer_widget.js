var classorg_1_1geoimage_1_1viewer_1_1widget_1_1_layer_widget =
[
    [ "LayerWidget", "classorg_1_1geoimage_1_1viewer_1_1widget_1_1_layer_widget.html#af367c4189abb7a0b515e87666bfd12a5", null ],
    [ "getLayer", "classorg_1_1geoimage_1_1viewer_1_1widget_1_1_layer_widget.html#a6dd64b51fe8d7e50fa811af454417445", null ],
    [ "setLayer", "classorg_1_1geoimage_1_1viewer_1_1widget_1_1_layer_widget.html#a965e0e70625e1dfe845cb8fae91c5118", null ]
];