var classorg_1_1geoimage_1_1viewer_1_1core_1_1gui_1_1manager_1_1_widget_manager =
[
    [ "addWidget", "classorg_1_1geoimage_1_1viewer_1_1core_1_1gui_1_1manager_1_1_widget_manager.html#a4eb3985f18f8287604404a364b79107b", null ],
    [ "createWidget", "classorg_1_1geoimage_1_1viewer_1_1core_1_1gui_1_1manager_1_1_widget_manager.html#a8f8f7b98b8d7efe80c59c1dcf290084c", null ],
    [ "getWidgetNames", "classorg_1_1geoimage_1_1viewer_1_1core_1_1gui_1_1manager_1_1_widget_manager.html#aeb2fcc9b96be2e715fd61cce0556c5db", null ]
];