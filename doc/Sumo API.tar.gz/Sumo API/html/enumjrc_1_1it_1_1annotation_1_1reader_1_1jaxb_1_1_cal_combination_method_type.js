var enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_cal_combination_method_type =
[
    [ "CalCombinationMethodType", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_cal_combination_method_type.html#ab57133aa25839a6fc1503a735c220e4c", null ],
    [ "value", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_cal_combination_method_type.html#afde68eb58c35496d1e213f247f58a9a5", null ],
    [ "XmlEnumValue", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_cal_combination_method_type.html#a02421bce5425031e8a14668147f22546", null ]
];