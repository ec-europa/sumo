var dir_c7be825f76b86955592e8cff183d4af6 =
[
    [ "BinaryReader.java", "_binary_reader_8java.html", [
      [ "BinaryReader", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_binary_reader.html", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_binary_reader" ]
    ] ],
    [ "CeosBinaryReader.java", "_ceos_binary_reader_8java.html", [
      [ "CeosBinaryReader", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_ceos_binary_reader.html", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_ceos_binary_reader" ]
    ] ],
    [ "GeoToolsGDALReader.java", "_geo_tools_g_d_a_l_reader_8java.html", [
      [ "GeoToolsGDALReader", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_geo_tools_g_d_a_l_reader.html", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_geo_tools_g_d_a_l_reader" ]
    ] ],
    [ "IReader.java", "_i_reader_8java.html", [
      [ "IReader", "interfaceorg_1_1geoimage_1_1impl_1_1imgreader_1_1_i_reader.html", "interfaceorg_1_1geoimage_1_1impl_1_1imgreader_1_1_i_reader" ]
    ] ],
    [ "PureGDALReader.java", "_pure_g_d_a_l_reader_8java.html", [
      [ "PureGDALReader", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_pure_g_d_a_l_reader.html", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_pure_g_d_a_l_reader" ]
    ] ],
    [ "S1TIFF.java", "_s1_t_i_f_f_8java.html", [
      [ "S1TIFF", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_s1_t_i_f_f.html", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_s1_t_i_f_f" ]
    ] ],
    [ "TIFF.java", "_t_i_f_f_8java.html", [
      [ "TIFF", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_t_i_f_f.html", "classorg_1_1geoimage_1_1impl_1_1imgreader_1_1_t_i_f_f" ]
    ] ]
];