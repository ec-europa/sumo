var classorg_1_1geoimage_1_1impl_1_1_gcp =
[
    [ "Gcp", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#adc351a2bb50989a7a35c5b718ec30adf", null ],
    [ "Gcp", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#ae9d9614f9b51b4c2b33c6a837af84c1d", null ],
    [ "getAngle", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#ac10b0028eb63280e30706668db6f3875", null ],
    [ "getOriginalXpix", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a14d9188ca4160bd64d504c823c80b85b", null ],
    [ "getXgeo", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#ade420f6a96454bd1a0f7b72f5f7819b0", null ],
    [ "getXpix", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a949c15673a4a276351d399c98cdad223", null ],
    [ "getYgeo", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a44871e7cb30d649310d12fc64639163e", null ],
    [ "getYpix", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a3ea6b993479ac2d7580e4b0b5a1f6974", null ],
    [ "getZgeo", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a1a816f536d61110fcde73bd6ba4c9ef9", null ],
    [ "setAngle", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#aeaa80ce6a489ea20e1d2788b2e024e9b", null ],
    [ "setOriginalXpix", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#aa7091f56998c909391a9ff8bf45d6e44", null ],
    [ "setXgeo", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#aeb459900cb152988604fb0d69a2a715b", null ],
    [ "setXpix", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a3fb77c854c16e65e07d98f6a0f84411b", null ],
    [ "setYgeo", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a5d7413e7316a0fb3b7c797655910fad9", null ],
    [ "setYpix", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#ae55918c3e729773d2ed1cc8b20a66ac1", null ],
    [ "setZgeo", "classorg_1_1geoimage_1_1impl_1_1_gcp.html#a1e5e65729622ef2a057cd2f3d896c45d", null ]
];