var enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_aocs_op_mode_type =
[
    [ "AocsOpModeType", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_aocs_op_mode_type.html#a396e679a81919574cfe61dc5ea732ffb", null ],
    [ "value", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_aocs_op_mode_type.html#aa9a4277af6d7b0fb332ac2f1dc84706d", null ],
    [ "XmlEnumValue", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_aocs_op_mode_type.html#a62e1e9ec92573c79a7b0bdfcb5611f51", null ]
];