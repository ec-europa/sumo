var interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable =
[
    [ "isAddAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#abe2033811606f05abbb587cfa2cdef60", null ],
    [ "isChangeAttributesAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#af9782821224539cc0ad6395e829512ff", null ],
    [ "isDeleteAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#a7bc91d8fc1e1de8ff77453bca6267b1e", null ],
    [ "isEditable", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#afe4af76ab6f7e737d256ef1ec9be7780", null ],
    [ "isMoveAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#a758f53eb98a3303702444157a145e7c8", null ],
    [ "setAddAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#a77d258ce3845a18be035eda01e35e031", null ],
    [ "setChangeAttributesAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#a3d287253cb5a8ae21f2f7934078fedbc", null ],
    [ "setDeleteAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#a05ff6c1523e8c60b2559829e49caa1ef", null ],
    [ "setEditable", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#a3cbc2b410d66b7fff11fc61547b435bc", null ],
    [ "setMoveAction", "interfaceorg_1_1geoimage_1_1viewer_1_1core_1_1api_1_1_i_editable.html#aaa74f043034cde4db83945fe19042316", null ]
];