var classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array =
[
    [ "getCount", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#a5a65e6ea8bf3491f7591438bb7100310", null ],
    [ "getUnits", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#a6c9b8dc3003091bdb62bdc7350f21bbd", null ],
    [ "getValue", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#ac49273356f4ebe69e3d062e7ed7f6fbe", null ],
    [ "setCount", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#acfaf67062f5dfbecbe53746900fb8c01", null ],
    [ "setUnits", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#a65e00c09355bc345db8503ef9f6e5b30", null ],
    [ "setValue", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#ab2b767ac607c68e289ffafab0ccc87ac", null ],
    [ "count", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#a5aee99936967aa5aafa11ae0264117eb", null ],
    [ "units", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#a6351fc9fbf2a1530b8cf6d1830395963", null ],
    [ "value", "classjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_double_coefficient_array.html#a1b83c3c7558941eb00a1095f8d7a53ff", null ]
];