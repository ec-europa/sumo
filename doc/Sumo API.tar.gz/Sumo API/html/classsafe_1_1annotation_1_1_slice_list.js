var classsafe_1_1annotation_1_1_slice_list =
[
    [ "getCount", "classsafe_1_1annotation_1_1_slice_list.html#ad1deecb2aed66e855e3f79cf100d4263", null ],
    [ "setCount", "classsafe_1_1annotation_1_1_slice_list.html#a2b9d068b3bf2a7e057e989b19af45620", null ],
    [ "count", "classsafe_1_1annotation_1_1_slice_list.html#a94c67a712435389ce2340f701f74c660", null ]
];