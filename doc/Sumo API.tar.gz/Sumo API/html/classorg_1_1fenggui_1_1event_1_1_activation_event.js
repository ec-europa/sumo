var classorg_1_1fenggui_1_1event_1_1_activation_event =
[
    [ "ActivationEvent", "classorg_1_1fenggui_1_1event_1_1_activation_event.html#a8a5fc13a0f150e10c1db63e082069602", null ],
    [ "isEnabled", "classorg_1_1fenggui_1_1event_1_1_activation_event.html#a914d7ec5aab29ad8ed7e68dd6fe9d0c6", null ]
];