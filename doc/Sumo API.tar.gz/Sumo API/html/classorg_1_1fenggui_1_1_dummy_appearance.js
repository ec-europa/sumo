var classorg_1_1fenggui_1_1_dummy_appearance =
[
    [ "getMinSizeHint", "classorg_1_1fenggui_1_1_dummy_appearance.html#a4e62f43d2a6c65717ddf82d5fa29640b", null ],
    [ "paint", "classorg_1_1fenggui_1_1_dummy_appearance.html#aecf24b015aefd74c69fff5b33f371d36", null ]
];