var interfaceorg_1_1fenggui_1_1render_1_1_i_texture =
[
    [ "bind", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#a0d43d383ae3206fa8855cfb8a31b500f", null ],
    [ "getID", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#a10e1084f923a11697e589a3066cceb56", null ],
    [ "getImageHeight", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#abf1177a55715aa11a8edca169cc9bc25", null ],
    [ "getImageWidth", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#aa36b5780ff60fc9c81c281686014f0f1", null ],
    [ "getTextureHeight", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#a01473ab569e998c2532e27811468d870", null ],
    [ "getTextureWidth", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#a3adfca81eb70d812971eb2fe2a469d61", null ],
    [ "hasAlpha", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#a95e416509b1bebfe570662526f69f6ae", null ],
    [ "texSubImage2D", "interfaceorg_1_1fenggui_1_1render_1_1_i_texture.html#a4e68f5ba448ebe16815a2b8eac0a98e8", null ]
];