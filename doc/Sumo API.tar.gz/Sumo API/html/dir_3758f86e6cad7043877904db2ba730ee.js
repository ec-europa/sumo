var dir_3758f86e6cad7043877904db2ba730ee =
[
    [ "gdalinfo.java", "gdalinfo_8java.html", [
      [ "gdalinfo", "classothers_1_1tiff_1_1gdal_1_1gdalinfo.html", null ]
    ] ],
    [ "GDALReader.java", "_g_d_a_l_reader_8java.html", [
      [ "GDALReader", "classothers_1_1tiff_1_1gdal_1_1_g_d_a_l_reader.html", "classothers_1_1tiff_1_1gdal_1_1_g_d_a_l_reader" ]
    ] ],
    [ "GDALtest.java", "_g_d_a_ltest_8java.html", [
      [ "GDALtest", "classothers_1_1tiff_1_1gdal_1_1_g_d_a_ltest.html", "classothers_1_1tiff_1_1gdal_1_1_g_d_a_ltest" ]
    ] ]
];