var classorg_1_1geoimage_1_1viewer_1_1widget_1_1_preferences_dialog =
[
    [ "PreferencesDialog", "classorg_1_1geoimage_1_1viewer_1_1widget_1_1_preferences_dialog.html#a62e7f21f78cfc35b4c2c92c33886a527", null ],
    [ "exit", "classorg_1_1geoimage_1_1viewer_1_1widget_1_1_preferences_dialog.html#ab7a5c780779cfae8ab07908243e95820", null ]
];