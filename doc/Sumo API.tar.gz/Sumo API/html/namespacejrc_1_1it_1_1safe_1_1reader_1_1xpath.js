var namespacejrc_1_1it_1_1safe_1_1reader_1_1xpath =
[
    [ "object", "namespacejrc_1_1it_1_1safe_1_1reader_1_1xpath_1_1object.html", "namespacejrc_1_1it_1_1safe_1_1reader_1_1xpath_1_1object" ]
];