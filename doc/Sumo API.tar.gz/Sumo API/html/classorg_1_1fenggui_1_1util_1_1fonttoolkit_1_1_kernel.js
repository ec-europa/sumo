var classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel =
[
    [ "Kernel", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#a3d836fa1cbc94cdb0339f3aba68c5238", null ],
    [ "Kernel", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#a04065e664edd224551d9112442941c31", null ],
    [ "add", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#a20f39cb5039b70efc80b6e277bcde8e6", null ],
    [ "add", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#afba4e62072190bad83c88f51eebf3431", null ],
    [ "getHeight", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#a99ded491e35d178969a41a12f51e7f41", null ],
    [ "getValue", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#af5445a564586bb43867f0796e83eab16", null ],
    [ "getWidth", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#abdaac03856966dd165a9f5f8bbc7ad02", null ],
    [ "multiply", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#acd1a5eb58be34712cb949218260e9a88", null ],
    [ "toString", "classorg_1_1fenggui_1_1util_1_1fonttoolkit_1_1_kernel.html#a004582fd32505e0f820276469bb0b1cd", null ]
];