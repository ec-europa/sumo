var enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_product_class_description_type =
[
    [ "ProductClassDescriptionType", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_product_class_description_type.html#a9e0404f26a3c10d23e590409aa223ea6", null ],
    [ "value", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_product_class_description_type.html#a49d8759d247cad15ae7086791c0c650f", null ],
    [ "XmlEnumValue", "enumjrc_1_1it_1_1annotation_1_1reader_1_1jaxb_1_1_product_class_description_type.html#a7f960704ceb19ae84a4b34666921d187", null ]
];