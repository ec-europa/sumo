var classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software =
[
    [ "getName", "classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software.html#addc0425e87ada0cec6e85d41e2db3d1b", null ],
    [ "getVersion", "classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software.html#a05d083d6f24b637657d8f8884a1c45ae", null ],
    [ "setName", "classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software.html#a4ffa2079cb22da252bcf492c62201ec3", null ],
    [ "setVersion", "classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software.html#ab45448889544777943751df6448e8e36", null ],
    [ "name", "classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software.html#a90b84dc27d90f145195ff3dd3b45e081", null ],
    [ "version", "classjrc_1_1it_1_1safe_1_1reader_1_1jaxb_1_1_software.html#a546dd7ce6a4e5f5ca4d8934d0ea2c562", null ]
];