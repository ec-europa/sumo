var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz",
  1: "abcdefghijklmnopqrstuvwxz",
  2: "jost",
  3: "abcdefghijklmnopqrstuvwxz",
  4: "_abcdefghijklmnopqrstuvwxz",
  5: "_abcdefghiklmnopqrstuvwxyz",
  6: "copv",
  7: "dt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerator",
  7: "Pages"
};

